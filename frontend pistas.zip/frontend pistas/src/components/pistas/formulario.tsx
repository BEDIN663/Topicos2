import Entrada from "./entrada";
import { useState } from "react";
import Botao from "./botao";
import Pista from "@/core/Pista";

interface FormularioProps {
    pista: Pista
    pistaMudou?: (pista: Pista) => void
    cancelada?: () => void
}

export default function Formulario(props: FormularioProps) {
    const id = props.pista?.id
    const [nome, setNome] = useState(props.pista?.nome)
    const [comprimento, setComprimento] = useState(props.pista?.comprimento)
    const [localizacao, setLocalizacao] = useState(props.pista?.localizacao)
    const [tipoTerreno, setTipoTerreno] = useState(props.pista?.tipoTerreno)

    return (
        <div>
            {id ? (<Entrada texto="id" valor={id} somenteLeitura></Entrada>) : false}
            <Entrada texto="Nome" valor={nome} onChange={setNome}></Entrada>
            <Entrada texto="Comprimento" tipo="number" valor={comprimento} onChange={setComprimento}></Entrada>
            <Entrada texto="Localização" valor={localizacao} onChange={setLocalizacao}></Entrada>
            <Entrada texto="Tipo Terreno" valor={tipoTerreno} onChange={setTipoTerreno}></Entrada>
            <div className="flex justify-end mt-5">
                <Botao className="mr-3" cor="bg-gradient-to-r from-green-500 to-green-700"
                    onClick={() => props.pistaMudou?.(new Pista(
                        id, nome, comprimento, localizacao, tipoTerreno))}>
                    {id ? 'Alterar' : 'Salvar'}
                </Botao>
                <Botao cor="bg-gradient-to-r from-green-500 to-green-700"
                    onClick={props.cancelada}>
                    Cancelar
                </Botao>
            </div>
        </div>
    )
}