
import Pista from "@/core/Pista"
import { IconeEdicao, IconeLixo } from "../icones/tabela"

interface TabelaProps {
    pistas: Pista[]
    pistaSelecionada?: (pista: Pista) => void
    pistaExcluida?: (pista: Pista) => void
}

export default function Tabela(props: TabelaProps) {
    
    const exibirAcoes = props.pistaSelecionada || props.pistaExcluida

    function renderHeader() {
        return (
            <tr>
                <th className="text-left p-3">Id</th>
                <th className="text-left p-3">Nome</th>
                <th className="text-left p-3">Comprimento</th>
                <th className="text-left p-3">Localização</th>
                <th className="text-left p-3">Tipo do Terreno</th>
                {exibirAcoes ? <th className="p-3">Ações</th> : false}
            </tr>
        )
    }

    function renderDados() {
        return props.pistas?.map((pista, i) => {
            return (
                <tr key={pista.id}
                    className={`${i % 2 === 0 ? 'bg-green-200' : 'bg-green-100'} `}>
                    <td className="text-left p-3">{pista.id}</td>
                    <td className="text-left p-3">{pista.nome}</td>
                    <td className="text-left p-3">{pista.comprimento}</td>
                    <td className="text-left p-3">{pista.localizacao}</td>
                    <td className="text-left p-3">{pista.tipoTerreno}</td>
                    {exibirAcoes 
                    ? renderizarAcoes(pista)
                    : false }
                </tr>
            )
        })
    }

    function renderizarAcoes(pista: Pista) {
        return (
            <td className="flex justify-center">
                {props.pistaSelecionada ? (
                    <button onClick={() => props.pistaSelecionada?.(pista)} className={`flex justify-center items
                    text-blue-600 rounded-full p-2 m-1
                    hover:bg-gray-100`}>{IconeEdicao}</button>
                ) : false }
                {props.pistaExcluida ? (
                    <button onClick={() => props.pistaExcluida?.(pista)} className={`flex justify-center items
                    text-red-600 rounded-full p-2 m-1
                    hover:bg-gray-100`}>{IconeLixo}</button>
                ) : false}
            </td>
        )
    }

    return (
        <table className="w-full rounded-xl overflow-hidden">
            <thead className={`text-gray-100
            bg-gradient-to-r from-green-500 to-green-800`}>
                {renderHeader()}
            </thead>
            <tbody>
                {renderDados()}
            </tbody>
        </table>
    )
}