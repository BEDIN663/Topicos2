import React from "react";

export default function Navbar(props: any) {
    const estiloNavbar = {
        borderBottomLeftRadius: '10px',
        borderBottomRightRadius: '10px'
    };

    return (
        <>
            <nav className="font-sans flex flex-col text-center sm:flex-row sm:text-left sm:justify-between py-4 px-6 bg-gradient-to-r from-green-600 to-green-800 shadow sm:items-baseline w-full" style={estiloNavbar}>
                <div className="mb-10 sm:mb-0">
                    <strong style={{ color: 'white', fontSize: '24px' }}>Sistema de Pistas</strong>
                </div>
                <div>
                    <a href="/" className="text-lg no-underline hover:text-lime-200 ml-2">
                        <strong style={{ color: 'white' }}>Home</strong>
                    </a>
                    <a href="/pistas" className="text-lg no-underline hover:text-lime-200 ml-2">
                        <strong style={{ color: 'white' }}>Pistas</strong>
                    </a>
                </div>
            </nav>
        </>
    );
}
