export default function Home() {
  return (
    <div style={{ textAlign: 'center', padding: '50px' }}>
      <div style={{ backgroundColor: 'lightgreen', display: 'inline-block', padding: '10px', borderRadius: '20px' }}>
        <h2 style={{ color: 'black', margin: '0', fontSize: '24px' }}><strong>Sistema de Pistas Inicio</strong></h2>
      </div>
    </div>
  )
}
