'use client';
import Botao from "@/components/pistas/botao";
import Formulario from "@/components/pistas/formulario";
import Layout from "@/components/pistas/layout";
import Tabela from "@/components/pistas/tabela";
import Pista from "@/core/Pista";
import { atualizarPista, cadastrarPista, excluirPista, fetchPistas } from "@/service/pistaService";
import { useEffect, useState } from "react";

export default function Pistas() {

  const [pista, setPista] = useState<Pista>(Pista.vazia())
  const [visivel, setVisivel] = useState<'tabela' | 'form'>('tabela')

  const [pistas, setPistas] = useState<Pista[]>([]);

  useEffect(() => {
    if (visivel === 'tabela') {
      const loadPistas = async () => {
        try {
          const dados = await fetchPistas();
          setPistas(dados);
        } catch (error) {
          console.error("Erro ao buscar pista:", error);
        }
      }

      loadPistas();
    }
  }, [visivel]);


  function pistaSelecionada(pista: Pista) {
    setPista(pista)
    setVisivel('form')
  }

  async function pistaExcluida(pista: Pista) {
    const confirmacao = window.confirm("Tem certeza de que deseja excluir esta pista?");
    if (confirmacao) {
      try {
        if (pista.id !== null) {
          await excluirPista(pista.id);
        } else {
          console.error("pistaId é null!");
        }
        setPistas(prevPistas => prevPistas.filter(ev => ev.id !== pista.id));
      } catch (error) {
        console.error("Erro ao excluir pista:", error);
      }
    }
  }

  function salvarOuAlterarPista(pista: Pista) {
    if (pista.id) {
      alterarPista(pista)
    } else {
      salvarPista(pista)
    }
  }

  async function alterarPista(pista: Pista) {
    try {
      const pistaAtualizada = await atualizarPista(pista);
      setVisivel("tabela");
    } catch (error) {
      console.error("Erro ao atualizar pista:", error);
    }
  }

  async function salvarPista(pista: Pista) {
    try {
      const novaPista = await cadastrarPista(pista);
      setVisivel("tabela");
    } catch (error) {
      console.error("Erro ao salvar pista:", error);
    }
  }

  function novaPista() {
    setPista(Pista.vazia())
    setVisivel("form")
  }

  return (
    <div className={`
     flex justify-center items-center h-screen
     bg-gradient-to-bl from-green-900 via-green-400 to-green-900
     text-white`}
      style={{ backgroundImage: `url('2.jpg')` }}>
      <Layout titulo ="Cadastro de Pistas">
        {visivel === 'tabela' ? (
          <>
            <div className="flex justify-end">
              <Botao className="mb-4" cor="bg-gradient-to-r from-green-500 to-green-700"
                onClick={() => novaPista()}>
                Nova Pista
              </Botao>
            </div>
            <Tabela pistas={pistas}
              pistaSelecionada={pistaSelecionada}
              pistaExcluida={pistaExcluida}></Tabela>
          </>
        ) : (
          <Formulario pista={pista}
            pistaMudou={salvarOuAlterarPista}
            cancelada={() => setVisivel('tabela')} />
        )}
      </Layout>
    </div>
  )
}
