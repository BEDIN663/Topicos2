import Pista from '../core/Pista';
let pistasList: Pista[] = [
  new Pista(1, "Glen Hellen",
    2500,
    "California",
    "Arenoso",
  ),
  new Pista(2, "Pista Duda Parise",
    1700,
    "Fagundes Varela",
    "Duro",
  )
]
let proximoId = pistasList.length + 1;

export const fetchPistas = async (): Promise<Pista[]> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    return pistasList;
  } catch (error) {
    throw new Error('Erro ao buscar pista');
  }
};

export const cadastrarPista = async (novaPista: Pista): Promise<Pista> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    novaPista.id = proximoId++;
    pistasList.push(novaPista);
    return novaPista;
  } catch (error) {
    console.error("Erro ao cadastrar pista:", error);
    throw error;
  }
};

export const atualizarPista = async (pistaAtualizada: Pista): Promise<Pista> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    const index = pistasList.findIndex((pista) => pista.id === pistaAtualizada.id);
    if (index !== -1) {
      pistasList[index] = pistaAtualizada;
      return pistaAtualizada;
    } else {
      throw new Error('Pista não encontrado');
    }
  } catch (error) {
    console.error("Erro ao atualizar pista:", error);
    throw error;
  }
};

export const excluirPista = async (id: number): Promise<void> => {
  try {
    await new Promise((resolve) => setTimeout(resolve, 500));
    pistasList = pistasList.filter((pista) => pista.id !== id);
  } catch (error) {
    console.error("Erro ao excluir pista:", error);
    throw error;
  }
};

