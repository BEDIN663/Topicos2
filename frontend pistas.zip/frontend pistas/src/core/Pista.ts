export default class Pista {
  id: number | null;
  nome: string;
  comprimento: number;
  localizacao: string;
  tipoTerreno: string;

  constructor(id: number | null, nome: string, comprimento: number, localizacao: string, tipoTerreno: string) {
    this.id = id;
    this.nome = nome;
    this.comprimento = comprimento;
    this.localizacao = localizacao;
    this.tipoTerreno = tipoTerreno;
  }

  static geraPistasMock() {
    return [
      new Pista(1, "Pista 1", 5000, "Cidade A", "Asfalto"),
      new Pista(2, "Pista 2", 3000, "Cidade B", "Terra")
    ];
  }

  static vazia(): Pista {
    return new Pista(null, "", 0, "", "");
  }
}
