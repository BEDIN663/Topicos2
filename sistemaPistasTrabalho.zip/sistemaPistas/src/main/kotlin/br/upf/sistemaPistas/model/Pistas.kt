package br.upf.sistemaPistas.model

data class Pistas(
    val id: Long? = null,
    val circuito: String,
    val descricao: String
)