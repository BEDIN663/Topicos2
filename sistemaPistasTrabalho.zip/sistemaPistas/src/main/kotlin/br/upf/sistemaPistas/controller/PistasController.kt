package br.upf.sistemaPistas.controller

import br.upf.sistemaPistas.model.Pistas
import br.upf.sistemaPistas.service.PistasService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/pistas")
class PistasController(private val service: PistasService) {

    @GetMapping
    fun listar(): MutableList<Pistas> {
        return service.listar()
    }

    @PostMapping
    fun cadastrar(@RequestBody pista: Pistas) {
        service.cadastrar(pista)
    }
}