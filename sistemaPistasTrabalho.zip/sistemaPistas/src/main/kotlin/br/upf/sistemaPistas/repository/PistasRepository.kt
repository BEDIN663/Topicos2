package br.upf.sistemaPistas.repository

import br.upf.sistemaPistas.model.Pistas
import org.springframework.stereotype.Repository

@Repository
class PistasRepository {
    private val pistas: MutableList<Pistas> = mutableListOf()

    init {
        val pista1 = Pistas(
            id = 1,
            circuito = "Fagundes Varella",
            descricao = "Motocross Raiz"
        )
        pistas.add(pista1)
    }

    fun findAll(): MutableList<Pistas> {
        return pistas
    }

    fun cadastrar(pista: Pistas) {
        pistas.add(pista)
    }
}