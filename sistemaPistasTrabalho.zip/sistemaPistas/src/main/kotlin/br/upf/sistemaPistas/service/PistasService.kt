package br.upf.sistemaPistas.service

import br.upf.sistemaPistas.model.Pistas
import br.upf.sistemaPistas.repository.PistasRepository
import org.springframework.stereotype.Service

@Service
class PistasService(private val repository: PistasRepository) {
    fun listar(): MutableList<Pistas> {
        return repository.findAll()
    }

    fun cadastrar(pista: Pistas) {
        repository.cadastrar(pista)
    }
}